The folder names explain our tunabled parameters:
 - Q = COUNTDOWN_TO_QUARANTINE_CHECK, so, for e.g: Q40 means COUNTDOWN_TO_QUARANTINE_CHECK every 40 seconds. Q40 = Quarantine people every 40 seconds.
 - E = COUNTDOWN_TILL_EPIDEMIC_SPREAD, so, for e.g: E60 means wait for 60 seconds and COUNTDOWN_TILL_EPIDEMIC_SPREAD. E60 = The first person becomes infected after a minute. 