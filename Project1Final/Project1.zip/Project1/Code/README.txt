AUTHORS: Siri Khalsa and Anas Gauba

This is all written in python3.

dependencies:

part3.py and Part3Fig4.py requires pip install jpype to run. this is needed for jdit tool

part4.py requires pip install p5 to run. this is needed for processing library for perlin noise and remap function.
part4.py also requires GLFW which is not installed by default on cs machines but can be installed:  sudo apt-get install libglfw3
here is the install guide - https://p5.readthedocs.io/en/latest/install.html


besides this numpy and matplotlib is required for all other python scripts.

